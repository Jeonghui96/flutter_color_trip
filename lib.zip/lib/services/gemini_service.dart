// lib/services/gemini_service.dart
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter/material.dart'; // debugPrint를 위해 import

class GeminiService {
  static final String? _apiKey = dotenv.env['GEMINI_API_KEY'];

  // 사용자 입력을 받아 Gemini에 요청
  static Future<String> getRecommendation(
    String userPrompt, {
    List<String> visitedLocations = const [], // visitedLocations 파라미터 추가
    bool excludeVisited = false, // excludeVisited 파라미터 추가 (기본값 false)
  }) async {
    if (_apiKey == null) {
      throw Exception('GEMINI_API_KEY is not set in .env file');
    }

    String finalSystemInstruction = '너는 한국인을 위한 친근한 여행 추천 전문가야. '
        '절대로 **굵은 글씨**, *, _, #, ` 등 마크다운 문법을 사용하지 마. '
        '문장은 평범하고 자연스럽게 써줘. 형식 없이 서술형 문장으로 알려줘. '
        '추천 장소의 매력과 이유를 구체적으로 설명해줘. '
        '과장된 표현 없이 진짜 여행 가이드처럼 알려줘.';

    // excludeVisited가 true이고, 방문 지역이 있을 경우에만 제외 지침을 추가
    if (excludeVisited && visitedLocations.isNotEmpty) {
      finalSystemInstruction += " 사용자가 이미 방문한 다음 장소들은 추천 목록에서 **반드시 제외해주세요**: ${visitedLocations.join(', ')}.";
    } else if (visitedLocations.isNotEmpty) {
      // excludeVisited가 false이지만 방문 지역 정보가 있는 경우, AI에게 참고하도록 전달
      // AI가 더 다양하고 개인화된 추천을 제공할 수 있도록 돕는 목적
      finalSystemInstruction += " 사용자가 방문했던 다음 지역들을 참고하여 추천해 주세요: ${visitedLocations.join(', ')}.";
    }

    final model = GenerativeModel(
      model: 'gemini-2.0-flash',
      apiKey: _apiKey!,
      systemInstruction: Content.text(finalSystemInstruction), // 동적으로 생성된 시스템 지침 사용
    );

    final content = [Content.text("사용자의 여행 스타일: $userPrompt")];
    final response = await model.generateContent(content);
    final raw = response.text ?? '추천을 찾을 수 없습니다.';

    debugPrint('Gemini System Instruction: $finalSystemInstruction'); // 실제 전송되는 시스템 지침 확인
    debugPrint('Gemini Response Raw: $raw'); // Gemini의 원본 응답 확인

    return _cleanMarkdown(raw);
  }

  // 마크다운 스타일 제거
  static String _cleanMarkdown(String raw) {
    return raw
        .replaceAll(RegExp(r'\\n'), '\n')           // 줄바꿈 복원
        .replaceAll(RegExp(r'[*_`#>-]+'), '')       // 마크다운 기호 제거
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')      // 3줄 이상 공백 → 2줄로
        .trim();
  }
}